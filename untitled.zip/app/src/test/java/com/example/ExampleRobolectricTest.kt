package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.manager.TunnelManager
import com.example.model.LogLevel
import com.example.model.TunnelConfig
import com.example.model.TunnelStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("DarkTunnel VPN", appName)
    }

    @Test
    fun `tunnel manager initialization and config update`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        TunnelManager.initialize(context)

        TunnelManager.updateServerHost("1.1.1.1")
        TunnelManager.updateServerPort(853)
        TunnelManager.updateSniHostname("one.one.one.one")
        TunnelManager.updateHttpPayload("CONNECT [host_port] HTTP/1.1[crlf][crlf]")

        val config = TunnelManager.config.value
        assertEquals("1.1.1.1", config.serverHost)
        assertEquals(853, config.serverPort)
        assertEquals("one.one.one.one", config.sniHostname)
        assertTrue(config.httpPayload.contains("CONNECT"))

        TunnelManager.addLog(LogLevel.INFO, "Test log message")
        assertTrue(TunnelManager.logs.value.isNotEmpty())
    }
}
