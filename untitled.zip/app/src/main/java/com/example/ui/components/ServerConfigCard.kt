package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.TunnelConfig
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkBorderFocused
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.TerminalCodeBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ServerConfigCard(
    config: TunnelConfig,
    isLocked: Boolean,
    onServerHostChange: (String) -> Unit,
    onServerPortChange: (Int) -> Unit,
    onSniHostnameChange: (String) -> Unit,
    onHttpPayloadChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val focusManager = LocalFocusManager.current
    var showSniHelp by remember { mutableStateOf(false) }
    var showPayloadHelp by remember { mutableStateOf(false) }

    val quickPorts = listOf(443, 80, 8080, 22, 3128, 8443)
    val payloadTags = listOf("[host_port]", "[host]", "[port]", "[protocol]", "[crlf]", "[ua]")

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(DarkSurfaceCard)
            .border(1.dp, DarkBorder, RoundedCornerShape(16.dp))
            .padding(16.dp)
            .testTag("server_config_card")
    ) {
        // Section Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Storage,
                contentDescription = null,
                tint = ElectricCyan,
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = "TUNNEL CONFIGURATION",
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    fontFamily = FontFamily.Monospace
                ),
                color = TextPrimary
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Row 1: Server IP and Port Inputs
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Server Host / IP
            OutlinedTextField(
                value = config.serverHost,
                onValueChange = onServerHostChange,
                enabled = !isLocked,
                label = { Text("Server Host / IP", fontSize = 12.sp) },
                placeholder = { Text("104.21.5.198", color = TextMuted) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Public,
                        contentDescription = "Server IP",
                        tint = if (isLocked) TextMuted else ElectricCyan,
                        modifier = Modifier.size(18.dp)
                    )
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Uri,
                    imeAction = ImeAction.Next
                ),
                colors = outlinedColors(),
                textStyle = MaterialTheme.typography.bodyMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Medium
                ),
                modifier = Modifier
                    .weight(1.8f)
                    .testTag("input_server_ip")
            )

            // Server Port
            OutlinedTextField(
                value = if (config.serverPort == 0) "" else config.serverPort.toString(),
                onValueChange = { str ->
                    val portVal = str.filter { it.isDigit() }.take(5).toIntOrNull() ?: 0
                    if (portVal <= 65535) {
                        onServerPortChange(portVal)
                    }
                },
                enabled = !isLocked,
                label = { Text("Port", fontSize = 12.sp) },
                placeholder = { Text("443", color = TextMuted) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Number,
                    imeAction = ImeAction.Next
                ),
                colors = outlinedColors(),
                textStyle = MaterialTheme.typography.bodyMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Medium
                ),
                modifier = Modifier
                    .weight(1f)
                    .testTag("input_server_port")
            )
        }

        // Quick Port Selection Chips
        if (!isLocked) {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                quickPorts.forEach { port ->
                    val isSelected = config.serverPort == port
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) ElectricCyan.copy(alpha = 0.2f) else DarkSurfaceElevated)
                            .border(
                                1.dp,
                                if (isSelected) ElectricCyan else DarkBorder,
                                RoundedCornerShape(6.dp)
                            )
                            .clickable { onServerPortChange(port) }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .testTag("quick_port_$port")
                    ) {
                        Text(
                            text = ":$port",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) ElectricCyan else TextSecondary
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Input 2: SNI Hostname
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "SNI HOSTNAME",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp,
                        fontFamily = FontFamily.Monospace
                    ),
                    color = ElectricCyan
                )
                Text(
                    text = "(TLS Extension)",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                    color = TextMuted
                )
            }

            IconButton(
                onClick = { showSniHelp = !showSniHelp },
                modifier = Modifier.size(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.HelpOutline,
                    contentDescription = "SNI Help",
                    tint = TextMuted,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        AnimatedVisibility(visible = showSniHelp) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(DarkSurfaceElevated)
                    .padding(8.dp)
            ) {
                Text(
                    text = "Server Name Indication (SNI) sends the requested domain during the TLS Client Hello handshake. Used to spoof hostnames or route via CDNs (e.g. Cloudflare, Fastly).",
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = TextSecondary
                )
            }
        }

        OutlinedTextField(
            value = config.sniHostname,
            onValueChange = onSniHostnameChange,
            enabled = !isLocked,
            placeholder = { Text("cloudflare.com or fast.com", color = TextMuted) },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "SNI Hostname",
                    tint = if (isLocked) TextMuted else ElectricCyan,
                    modifier = Modifier.size(18.dp)
                )
            },
            singleLine = true,
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Uri,
                imeAction = ImeAction.Next
            ),
            colors = outlinedColors(),
            textStyle = MaterialTheme.typography.bodyMedium.copy(
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Medium
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("input_sni_hostname")
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Input 3: Custom HTTP Payload
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "CUSTOM HTTP PAYLOAD",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp,
                        fontFamily = FontFamily.Monospace
                    ),
                    color = NeonGreen
                )
                Text(
                    text = "([crlf] supported)",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                    color = TextMuted
                )
            }

            IconButton(
                onClick = { showPayloadHelp = !showPayloadHelp },
                modifier = Modifier.size(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.HelpOutline,
                    contentDescription = "Payload Help",
                    tint = TextMuted,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        AnimatedVisibility(visible = showPayloadHelp) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(DarkSurfaceElevated)
                    .padding(8.dp)
            ) {
                Text(
                    text = "Define the initial raw HTTP request headers sent to the tunnel proxy server. Variables like [host_port], [host], [protocol], and [crlf] are dynamically replaced during connection.",
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = TextSecondary
                )
            }
        }

        // Quick Tag Insertion Bar
        if (!isLocked) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                payloadTags.forEach { tag ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(DarkSurfaceElevated)
                            .border(1.dp, DarkBorder, RoundedCornerShape(6.dp))
                            .clickable {
                                onHttpPayloadChange(config.httpPayload + tag)
                            }
                            .padding(horizontal = 6.dp, vertical = 4.dp)
                            .testTag("tag_$tag")
                    ) {
                        Text(
                            text = tag,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.SemiBold,
                            color = NeonGreen
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
        }

        OutlinedTextField(
            value = config.httpPayload,
            onValueChange = onHttpPayloadChange,
            enabled = !isLocked,
            placeholder = {
                Text(
                    "CONNECT [host_port] [protocol][crlf]Host: [host][crlf][crlf]",
                    color = TextMuted,
                    fontSize = 12.sp
                )
            },
            minLines = 3,
            maxLines = 5,
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = TerminalCodeBg,
                unfocusedContainerColor = TerminalCodeBg,
                disabledContainerColor = TerminalCodeBg.copy(alpha = 0.6f),
                focusedBorderColor = NeonGreen,
                unfocusedBorderColor = DarkBorder,
                disabledBorderColor = DarkBorder.copy(alpha = 0.4f),
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary,
                disabledTextColor = TextMuted
            ),
            textStyle = MaterialTheme.typography.bodySmall.copy(
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp,
                lineHeight = 16.sp
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("input_http_payload")
        )
    }
}

@Composable
private fun outlinedColors() = OutlinedTextFieldDefaults.colors(
    focusedContainerColor = DarkSurface,
    unfocusedContainerColor = DarkSurface,
    disabledContainerColor = DarkSurface.copy(alpha = 0.5f),
    focusedBorderColor = DarkBorderFocused,
    unfocusedBorderColor = DarkBorder,
    disabledBorderColor = DarkBorder.copy(alpha = 0.5f),
    focusedLabelColor = ElectricCyan,
    unfocusedLabelColor = TextSecondary,
    disabledLabelColor = TextMuted,
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextPrimary,
    disabledTextColor = TextMuted
)
