package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = NeonGreen,
    onPrimary = NeonGreenDark,
    primaryContainer = NeonGreenDark,
    onPrimaryContainer = NeonGreen,
    secondary = ElectricCyan,
    onSecondary = ElectricCyanDark,
    secondaryContainer = ElectricCyanDark,
    onSecondaryContainer = ElectricCyan,
    tertiary = AmberYellow,
    background = DarkBg,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceCard,
    onSurfaceVariant = TextSecondary,
    outline = DarkBorder,
    outlineVariant = DarkSurfaceElevated,
    error = VividRed,
    onError = TextPrimary,
    errorContainer = VividRedDark,
    onErrorContainer = VividRed
)

@Composable
fun DarkTunnelTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
