package com.example.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.net.VpnService
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.manager.TunnelManager
import com.example.model.LogLevel
import com.example.model.TunnelStatus
import com.example.ui.components.ConnectToggleButton
import com.example.ui.components.LiveLogArea
import com.example.ui.components.PresetsDialog
import com.example.ui.components.ServerConfigCard
import com.example.ui.components.StatusDisplayCard
import com.example.ui.components.TunnelHeader
import com.example.ui.theme.DarkBg
import com.example.vpn.CustomTunnelVpnService
import kotlinx.coroutines.launch

@Composable
fun DarkTunnelScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        TunnelManager.initialize(context)
    }

    val status by TunnelManager.status.collectAsStateWithLifecycle()
    val logs by TunnelManager.logs.collectAsStateWithLifecycle()
    val config by TunnelManager.config.collectAsStateWithLifecycle()
    val durationSeconds by TunnelManager.sessionDurationSeconds.collectAsStateWithLifecycle()
    val bytesIn by TunnelManager.bytesIn.collectAsStateWithLifecycle()
    val bytesOut by TunnelManager.bytesOut.collectAsStateWithLifecycle()
    val latencyMs by TunnelManager.latencyMs.collectAsStateWithLifecycle()

    var showPresetsDialog by remember { mutableStateOf(false) }

    // Launcher for Android VPN system preparation dialog
    val vpnLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            TunnelManager.addLog(LogLevel.VPN, "VPN access permission granted by user.")
            CustomTunnelVpnService.start(context)
        } else {
            TunnelManager.addLog(LogLevel.ERROR, "VPN permission prompt was declined or cancelled.")
            TunnelManager.setStatus(TunnelStatus.FAILED)
            scope.launch {
                snackbarHostState.showSnackbar("VPN permission is required to create tunnel.")
            }
        }
    }

    // Optional notification permission launcher for Android 13+
    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (!isGranted) {
            TunnelManager.addLog(LogLevel.WARNING, "Notification permission not granted. Status may not show in tray.")
        }
    }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    fun handleToggleConnect() {
        if (status == TunnelStatus.CONNECTED ||
            status == TunnelStatus.CONNECTING ||
            status == TunnelStatus.HANDSHAKING ||
            status == TunnelStatus.TUNNELING
        ) {
            CustomTunnelVpnService.stop(context)
        } else {
            if (config.serverHost.isBlank()) {
                scope.launch { snackbarHostState.showSnackbar("Please enter a valid Server Host or IP.") }
                return
            }
            if (config.serverPort <= 0 || config.serverPort > 65535) {
                scope.launch { snackbarHostState.showSnackbar("Please enter a valid Port (1-65535).") }
                return
            }

            val vpnIntent = VpnService.prepare(context)
            if (vpnIntent != null) {
                TunnelManager.addLog(LogLevel.INFO, "Requesting Android system VPN permission...")
                vpnLauncher.launch(vpnIntent)
            } else {
                CustomTunnelVpnService.start(context)
            }
        }
    }

    val isTunnelActive = status == TunnelStatus.CONNECTED ||
            status == TunnelStatus.CONNECTING ||
            status == TunnelStatus.HANDSHAKING ||
            status == TunnelStatus.TUNNELING

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = DarkBg,
        topBar = {
            TunnelHeader(
                status = status,
                onOpenPresets = { showPresetsDialog = true }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(DarkBg),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 640.dp)
                    .padding(horizontal = 16.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Spacer(modifier = Modifier.height(2.dp))

                // Status & Metrics Card
                StatusDisplayCard(
                    status = status,
                    config = config,
                    durationSeconds = durationSeconds,
                    bytesIn = bytesIn,
                    bytesOut = bytesOut,
                    latencyMs = latencyMs
                )

                // Prominent Connect / Disconnect Toggle Button
                ConnectToggleButton(
                    status = status,
                    onToggle = { handleToggleConnect() }
                )

                // Server IP, Port, SNI Hostname & Custom HTTP Payload Card
                ServerConfigCard(
                    config = config,
                    isLocked = isTunnelActive,
                    onServerHostChange = { TunnelManager.updateServerHost(it) },
                    onServerPortChange = { TunnelManager.updateServerPort(it) },
                    onSniHostnameChange = { TunnelManager.updateSniHostname(it) },
                    onHttpPayloadChange = { TunnelManager.updateHttpPayload(it) }
                )

                // Live Connection Updates & Terminal Log Area
                LiveLogArea(
                    logs = logs,
                    onClearLogs = { TunnelManager.clearLogs() }
                )

                Spacer(modifier = Modifier.height(24.dp))
            }
        }

        if (showPresetsDialog) {
            PresetsDialog(
                onDismiss = { showPresetsDialog = false },
                onSelectPreset = { preset ->
                    TunnelManager.updateConfig(
                        config.copy(
                            sniHostname = preset.sni,
                            httpPayload = preset.payload
                        )
                    )
                    TunnelManager.addLog(
                        LogLevel.INFO,
                        "Applied preset: '${preset.name}' (SNI: ${preset.sni})"
                    )
                }
            )
        }
    }
}
