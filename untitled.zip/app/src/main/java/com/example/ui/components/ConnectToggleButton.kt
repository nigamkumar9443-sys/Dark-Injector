package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.TunnelStatus
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.VividRed
import com.example.ui.theme.VividRedDark

@Composable
fun ConnectToggleButton(
    status: TunnelStatus,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isBusy = status == TunnelStatus.CONNECTING ||
            status == TunnelStatus.HANDSHAKING ||
            status == TunnelStatus.TUNNELING ||
            status == TunnelStatus.DISCONNECTING

    val isConnected = status == TunnelStatus.CONNECTED

    val infiniteTransition = rememberInfiniteTransition(label = "ring_pulse")
    val ringScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val activeColor by animateColorAsState(
        targetValue = when {
            isConnected -> NeonGreen
            isBusy -> ElectricCyan
            status == TunnelStatus.FAILED -> VividRed
            else -> ElectricCyan
        },
        label = "active_color"
    )

    val buttonBgGradient = when {
        isConnected -> Brush.verticalGradient(listOf(Color(0xFF00381A), Color(0xFF001F0E)))
        isBusy -> Brush.verticalGradient(listOf(Color(0xFF002C38), Color(0xFF001820)))
        status == TunnelStatus.FAILED -> Brush.verticalGradient(listOf(VividRedDark, Color(0xFF220807)))
        else -> Brush.verticalGradient(listOf(DarkSurfaceElevated, DarkSurface))
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(136.dp)
        ) {
            // Outer Pulsing Glow Ring (when active or busy)
            if (isConnected || isBusy) {
                Box(
                    modifier = Modifier
                        .size(136.dp)
                        .scale(ringScale)
                        .clip(CircleShape)
                        .background(activeColor.copy(alpha = 0.15f))
                        .border(1.5.dp, activeColor.copy(alpha = 0.4f), CircleShape)
                )
            }

            // Middle Decorative Ring
            Box(
                modifier = Modifier
                    .size(118.dp)
                    .clip(CircleShape)
                    .background(DarkSurfaceCard)
                    .border(2.dp, activeColor.copy(alpha = 0.7f), CircleShape)
            )

            // Inner Core Button
            Box(
                modifier = Modifier
                    .size(102.dp)
                    .clip(CircleShape)
                    .background(buttonBgGradient)
                    .border(1.5.dp, activeColor, CircleShape)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = ripple(bounded = true, radius = 54.dp),
                        onClick = onToggle
                    )
                    .testTag("connect_disconnect_button"),
                contentAlignment = Alignment.Center
            ) {
                if (isBusy) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(64.dp),
                        color = ElectricCyan,
                        strokeWidth = 3.dp
                    )
                }

                Icon(
                    imageVector = Icons.Default.PowerSettingsNew,
                    contentDescription = if (isConnected) "Disconnect" else "Connect",
                    tint = activeColor,
                    modifier = Modifier.size(46.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Text Action Label
        Text(
            text = when {
                isConnected -> "DISCONNECT"
                isBusy -> "ESTABLISHING..."
                status == TunnelStatus.FAILED -> "RECONNECT"
                else -> "START TUNNEL"
            },
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 2.sp,
                fontFamily = FontFamily.Monospace
            ),
            color = activeColor
        )

        Text(
            text = when {
                isConnected -> "TAP TO STOP SECURE TUNNEL"
                isBusy -> "NEGOTIATING HANDSHAKE"
                status == TunnelStatus.FAILED -> "LAST ATTEMPT FAILED"
                else -> "TAP BUTTON TO CONNECT"
            },
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 10.sp,
                letterSpacing = 1.sp
            ),
            color = TextMuted
        )
    }
}
