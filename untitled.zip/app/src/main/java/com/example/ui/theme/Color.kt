package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Terminal / Cyber Palette
val DarkBg = Color(0xFF0A0E17)
val DarkSurface = Color(0xFF121824)
val DarkSurfaceCard = Color(0xFF182030)
val DarkSurfaceElevated = Color(0xFF202B40)
val DarkBorder = Color(0xFF2A3750)
val DarkBorderFocused = Color(0xFF00E5FF)

val NeonGreen = Color(0xFF00E676)
val NeonGreenDark = Color(0xFF003D1A)
val ElectricCyan = Color(0xFF00E5FF)
val ElectricCyanDark = Color(0xFF003840)
val VividRed = Color(0xFFFF3B30)
val VividRedDark = Color(0xFF4A100E)
val AmberYellow = Color(0xFFFFB800)

val TextPrimary = Color(0xFFF0F4F8)
val TextSecondary = Color(0xFF8C9BAE)
val TextMuted = Color(0xFF5A697E)

val TerminalCodeBg = Color(0xFF080C12)
val TerminalCyan = Color(0xFF58D1FC)
val TerminalYellow = Color(0xFFFFDF5D)
val TerminalGreen = Color(0xFF5CF48C)
val TerminalPurple = Color(0xFFCF88FF)
val TerminalRed = Color(0xFFFF6363)
