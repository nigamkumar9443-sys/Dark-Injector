package com.example.model

enum class TunnelStatus(val label: String) {
    DISCONNECTED("Disconnected"),
    CONNECTING("Connecting..."),
    HANDSHAKING("SSL/TLS Handshake"),
    TUNNELING("Establishing Tunnel"),
    CONNECTED("Connected"),
    DISCONNECTING("Disconnecting..."),
    FAILED("Connection Failed")
}
