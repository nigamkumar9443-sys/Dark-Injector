package com.example.model

data class TunnelConfig(
    val serverHost: String = "104.21.5.198",
    val serverPort: Int = 443,
    val sniHostname: String = "cloudflare.com",
    val httpPayload: String = "CONNECT [host_port] [protocol][crlf]Host: [host][crlf]User-Agent: [ua][crlf]Connection: Keep-Alive[crlf][crlf]",
    val dnsServer: String = "8.8.8.8",
    val mtu: Int = 1500,
    val enableUdp: Boolean = true,
    val bypassLocalSubnets: Boolean = true
) {
    companion object {
        val PRESETS = listOf(
            PayloadPreset(
                name = "Standard HTTP CONNECT",
                description = "Classic HTTP proxy tunnel with keep-alive headers",
                sni = "cloudflare.com",
                payload = "CONNECT [host_port] [protocol][crlf]Host: [host][crlf]User-Agent: [ua][crlf]Connection: Keep-Alive[crlf][crlf]"
            ),
            PayloadPreset(
                name = "Cloudflare SNI Fronting",
                description = "Direct TLS connection spoofing Cloudflare edge hostname",
                sni = "speed.cloudflare.com",
                payload = "CONNECT [host_port] HTTP/1.1[crlf]Host: speed.cloudflare.com[crlf]X-Online-Host: speed.cloudflare.com[crlf]Connection: Keep-Alive[crlf][crlf]"
            ),
            PayloadPreset(
                name = "WebSocket Upgrade",
                description = "HTTP 101 Switching Protocols header for CDN WS tunneling",
                sni = "fast.com",
                payload = "GET / HTTP/1.1[crlf]Host: [host][crlf]Upgrade: websocket[crlf]Connection: Upgrade[crlf]Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==[crlf][crlf]"
            ),
            PayloadPreset(
                name = "Direct SSL / TLS",
                description = "Raw TLS encapsulation using target SNI hostname",
                sni = "gateway.discord.gg",
                payload = ""
            )
        )
    }
}

data class PayloadPreset(
    val name: String,
    val description: String,
    val sni: String,
    val payload: String
)
