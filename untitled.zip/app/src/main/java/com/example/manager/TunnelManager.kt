package com.example.manager

import android.content.Context
import android.content.SharedPreferences
import com.example.model.LogLevel
import com.example.model.TunnelConfig
import com.example.model.TunnelLog
import com.example.model.TunnelStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

object TunnelManager {

    private const val PREFS_NAME = "dark_tunnel_prefs"
    private const val KEY_SERVER_HOST = "key_server_host"
    private const val KEY_SERVER_PORT = "key_server_port"
    private const val KEY_SNI_HOST = "key_sni_host"
    private const val KEY_PAYLOAD = "key_payload"
    private const val KEY_DNS = "key_dns"

    private val _status = MutableStateFlow(TunnelStatus.DISCONNECTED)
    val status: StateFlow<TunnelStatus> = _status.asStateFlow()

    private val _logs = MutableStateFlow<List<TunnelLog>>(emptyList())
    val logs: StateFlow<List<TunnelLog>> = _logs.asStateFlow()

    private val _config = MutableStateFlow(TunnelConfig())
    val config: StateFlow<TunnelConfig> = _config.asStateFlow()

    private val _bytesIn = MutableStateFlow(0L)
    val bytesIn: StateFlow<Long> = _bytesIn.asStateFlow()

    private val _bytesOut = MutableStateFlow(0L)
    val bytesOut: StateFlow<Long> = _bytesOut.asStateFlow()

    private val _latencyMs = MutableStateFlow<Int?>(null)
    val latencyMs: StateFlow<Int?> = _latencyMs.asStateFlow()

    private val _sessionDurationSeconds = MutableStateFlow(0L)
    val sessionDurationSeconds: StateFlow<Long> = _sessionDurationSeconds.asStateFlow()

    private var durationJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main)
    private var prefs: SharedPreferences? = null

    fun initialize(context: Context) {
        if (prefs == null) {
            prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            loadSavedConfig()
            if (_logs.value.isEmpty()) {
                addLog(LogLevel.INFO, "DarkTunnel VPN client initialized.")
                addLog(LogLevel.INFO, "Ready to establish secure custom tunnel.")
            }
        }
    }

    private fun loadSavedConfig() {
        val p = prefs ?: return
        val default = TunnelConfig()
        val loaded = TunnelConfig(
            serverHost = p.getString(KEY_SERVER_HOST, default.serverHost) ?: default.serverHost,
            serverPort = p.getInt(KEY_SERVER_PORT, default.serverPort),
            sniHostname = p.getString(KEY_SNI_HOST, default.sniHostname) ?: default.sniHostname,
            httpPayload = p.getString(KEY_PAYLOAD, default.httpPayload) ?: default.httpPayload,
            dnsServer = p.getString(KEY_DNS, default.dnsServer) ?: default.dnsServer
        )
        _config.value = loaded
    }

    fun updateConfig(newConfig: TunnelConfig) {
        _config.value = newConfig
        prefs?.edit()?.apply {
            putString(KEY_SERVER_HOST, newConfig.serverHost)
            putInt(KEY_SERVER_PORT, newConfig.serverPort)
            putString(KEY_SNI_HOST, newConfig.sniHostname)
            putString(KEY_PAYLOAD, newConfig.httpPayload)
            putString(KEY_DNS, newConfig.dnsServer)
            apply()
        }
    }

    fun updateServerHost(host: String) {
        updateConfig(_config.value.copy(serverHost = host))
    }

    fun updateServerPort(port: Int) {
        updateConfig(_config.value.copy(serverPort = port))
    }

    fun updateSniHostname(sni: String) {
        updateConfig(_config.value.copy(sniHostname = sni))
    }

    fun updateHttpPayload(payload: String) {
        updateConfig(_config.value.copy(httpPayload = payload))
    }

    fun setStatus(newStatus: TunnelStatus) {
        _status.value = newStatus
        if (newStatus == TunnelStatus.CONNECTED) {
            startDurationTimer()
        } else if (newStatus == TunnelStatus.DISCONNECTED || newStatus == TunnelStatus.FAILED) {
            stopDurationTimer()
        }
    }

    fun addLog(level: LogLevel, message: String) {
        val entry = TunnelLog(level = level, message = message)
        val current = _logs.value.toMutableList()
        if (current.size >= 500) {
            current.removeAt(0)
        }
        current.add(entry)
        _logs.value = current
    }

    fun clearLogs() {
        _logs.value = emptyList()
        addLog(LogLevel.INFO, "Logs cleared.")
    }

    fun addTraffic(inBytes: Long, outBytes: Long) {
        _bytesIn.value += inBytes
        _bytesOut.value += outBytes
    }

    fun setLatency(ms: Int?) {
        _latencyMs.value = ms
    }

    fun resetStats() {
        _bytesIn.value = 0L
        _bytesOut.value = 0L
        _sessionDurationSeconds.value = 0L
        _latencyMs.value = null
    }

    private fun startDurationTimer() {
        durationJob?.cancel()
        _sessionDurationSeconds.value = 0L
        durationJob = scope.launch {
            while (isActive) {
                delay(1000)
                _sessionDurationSeconds.value += 1
            }
        }
    }

    private fun stopDurationTimer() {
        durationJob?.cancel()
        durationJob = null
    }
}
